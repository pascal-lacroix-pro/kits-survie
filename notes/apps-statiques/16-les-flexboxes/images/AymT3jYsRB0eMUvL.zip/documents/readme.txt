VALEURS:
Couleurs:

  - orange,
  - rgb(255,214,105) (orange clair - texte de liens off),
  - rgb(255,114,5) (orange foncé - fond liens active et hover),
  - #3D64A2 (bleu)
